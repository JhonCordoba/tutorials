export class CoordinatePlanePoint {
	westCoordinate!: number;
	southCoordinate!: number;
	color?: string;
}
