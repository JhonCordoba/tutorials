export class CreateDataFileDto {
	constructor(title: string, sizeOfSquareRegion: number, locations: Array<[number, number]>) {
		this.title = title;
		this.sizeOfSquareRegion = sizeOfSquareRegion;
		this.amountOfCities = locations.length;
		this.locations = "[|";
		locations.forEach((location) => {
			this.locations += location[0] + ", " + location[1] + "\n |";
		});
		this.locations += "]";
	}

	title!: string;
	sizeOfSquareRegion!: number;
	amountOfCities!: number;
	locations!: string;
}
