import { makeRequest } from "./index";
import { CreateDataFileDto } from "./dtos/create-data-file.dto";
import Swal from "sweetalert2";

export async function createDataFileRequest(createDataFileDto: CreateDataFileDto): Promise<any> {
	try {
		const response = await makeRequest(
			process.env.VUE_APP_API_URL + "data-file",
			{
				method: "POST",
			},
			createDataFileDto
		);

		Swal.fire({
			title: "Ready!",
			text: "The Data File was add succesfully.",
			icon: "success",
			confirmButtonText: "Cool",
		});

		//console.log("FROM FILE datafiles.ts, METHOD: createDataFileRequest: ", response);
		if (response.error) throw response;

		return response;
	} catch (error: any) {
		//console.log(error);
		Swal.fire({
			title: "Error!",
			text: "It happens an error, try again! " + error?.message[0],
			icon: "error",
			confirmButtonText: "Ok",
		});
	}
}

export async function calculateLandFillPositionRequest(dataFileId: string): Promise<any> {
	const startTime = new Date().getTime();

	try {
		const response = await makeRequest(
			process.env.VUE_APP_API_URL + "calculate-landfill-position",
			{
				method: "POST",
			},
			{ dataFileId }
		);

		//console.log("FROM FILE datafiles.ts, METHOD: calculateLandFillPositionRequest: ", response);

		if (response.error) throw response;

		const endTime = new Date().getTime();
		const timeTaken = endTime - startTime;

		Swal.fire({
			title: "Ready! The point calculated is:",
			text: response.result + "TimeTaken= " + timeTaken + "ms",
			icon: "success",
			confirmButtonText: "Cool",
		});

		return response;
	} catch (error: any) {
		//console.log(error);
		Swal.fire({
			title: "Error!",
			text:
				"It happens an error calculating the landfill position, try again! " +
				error?.message[0],
			icon: "error",
			confirmButtonText: "Ok",
		});
	}
}

export async function getDataFiles(): Promise<any> {
	try {
		const response = await makeRequest(
			process.env.VUE_APP_API_URL + "data-files",
			{
				method: "GET",
			},
			{}
		);
		//console.log("FROM FILE datafiles.ts, METHOD: getDataFiles: ", response);

		if (response.error) throw response;

		return response;
	} catch (error: any) {
		//console.log(error);
		Swal.fire({
			title: "Error!",
			text:
				"It happens an error getting the data files list, try again! " + error?.message[0],
			icon: "error",
			confirmButtonText: "Ok",
		});
	}
}

export async function getDataFile(dataFileId: string): Promise<any> {
	try {
		const response = await makeRequest(
			process.env.VUE_APP_API_URL + "get-data-file",
			{
				method: "POST",
			},
			{ dataFileId }
		);
		//console.log("FROM FILE datafiles.ts, METHOD: getDataFile: ", response);

		if (response.error) throw response;

		return response;
	} catch (error: any) {
		//console.log(error);
		Swal.fire({
			title: "Error!",
			text: "It happens an error getting the data file info, try again! " + error?.message[0],
			icon: "error",
			confirmButtonText: "Ok",
		});
	}
}
