<template>
	<div>
		<h2>Create Model Instances:</h2>
		<form onsubmit="return false;">
			<div class="inputCreateModelContainer">
				<label for="title">Title</label>
				<input
					id="title"
					v-model="title"
					class="titleInstanceInput"
					type="text"
					name="title"
					placeholder="Title"
				/>
			</div>

			<div class="inputCreateModelContainer">
				<label for="sizeOfSquareRegion">Size of the region</label>
				<input
					id="sizeOfSquareRegion"
					v-model="sizeOfSquareRegion"
					type="number"
					min="1"
					name="sizeOfSquareRegion"
					placeholder="Size of the Square Region"
				/>
			</div>

			<div class="addCityInputContainer">
				<input
					v-model="westPosition"
					type="number"
					name="westPosition"
					placeholder="West position"
					min="0"
					:max="sizeOfSquareRegion"
				/>
				<input
					v-model="southPosition"
					type="number"
					name="southPosition"
					placeholder="South position"
					min="0"
					:max="sizeOfSquareRegion"
				/>

				<button @click="addCity">Add city</button>
			</div>

			<div class="listOfCitiesToAddContainer">
				<div v-for="(location, index) in locations" :key="index" class="cityToAdd">
					<span style="color: rgb(84, 173, 214)">City {{ index + 1 }}:</span>
					west: {{ location[0] }} - south:
					{{ location[1] }}
				</div>
			</div>

			<button @click="sendCreateDataFileRequest">Create model instance</button>
		</form>
	</div>
</template>

<script lang="ts">
	import { defineComponent, Ref, ref } from "vue";
	import { createDataFileRequest } from "../requests/datafiles";
	import { CreateDataFileDto } from "../requests/dtos/create-data-file.dto";

	import { CoordinatePlanePoint } from "../types";

	export default defineComponent({
		name: "CreateDataFileForm",
		emits: ["updateGraphic"],
		setup(props, context) {
			/**
			 * locations is an array of number array 2x2, first number represents west position and second number represents south position.
			 */
			const locations: Ref<Array<[number, number]>> = ref([]);
			const title: Ref<string> = ref("");
			const sizeOfSquareRegion: Ref<number> = ref(1);

			const westPosition: Ref<number> = ref(1);
			const southPosition: Ref<number> = ref(1);

			function addCity() {
				locations.value.push([westPosition.value, southPosition.value]);

				const pointsToDraw: CoordinatePlanePoint[] = [];
				locations.value.forEach((location) => {
					pointsToDraw.push({
						westCoordinate: location[0],
						southCoordinate: location[1],
					});
				});

				context.emit("updateGraphic", [pointsToDraw, sizeOfSquareRegion.value, false]);
			}

			/**
			 * format data to create the CreateDataFileDto object and send request to api.
			 */
			async function sendCreateDataFileRequest() {
				const dataFileDto = new CreateDataFileDto(
					title.value,
					sizeOfSquareRegion.value,
					locations.value
				);
				await createDataFileRequest(dataFileDto);
			}

			return {
				locations,
				title,
				sizeOfSquareRegion,
				southPosition,
				westPosition,
				sendCreateDataFileRequest,
				addCity,
			};
		},
	});
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
	h2 {
		margin-top: 0;
		margin-bottom: 10px;
		text-decoration: underline;
		text-align: left;
		font-size: 1.3em;
	}
	.addCityInputContainer {
		margin: 1em;
		display: flex;
		width: 100%;
		justify-content: center;
	}

	.addCityInputContainer > input {
		width: 30%;
	}

	.listOfCitiesToAddContainer {
		height: 6em;
		overflow-y: scroll;
	}

	.inputCreateModelContainer {
		display: flex;
		margin: 3px;
	}

	label {
		width: 50%;
		text-transform: uppercase;
	}

	label::after {
		content: ":";
	}

	button {
		background-color: rgb(84, 173, 214);
		border: none;
		border-radius: 111px 111px 111px 111px;
		padding: 5px 5px;
		display: inline-block;
		color: white;
		font-weight: bold;
		font-size: 16px;
		cursor: pointer;
		margin: 2px;
	}
	button:hover {
		color: black;
	}

	.cityToAdd {
		cursor: pointer;
	}

	.cityToAdd:hover {
		font-size: 1.5em;
		font-style: bold;
	}
</style>
