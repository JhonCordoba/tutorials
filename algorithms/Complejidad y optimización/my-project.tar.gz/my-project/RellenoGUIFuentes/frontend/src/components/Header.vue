<template>
	<header>As Far As Possible From Nearest Point</header>
</template>

<script>
	import { defineComponent } from "vue";

	export default defineComponent({
		name: "HeaderApp",
		setup() {},
	});
</script>

<style scoped type="text/css">
	header {
		background: linear-gradient(
			90deg,
			rgba(2, 0, 36, 1) 0%,
			rgba(184, 164, 142, 1) 21%,
			rgba(0, 212, 255, 1) 100%
		);
		margin-bottom: 1em;
		height: 2em;
		color: white;
		font-weight: bold;

		display: flex;
		justify-content: center; /* align horizontal */
		align-items: center; /* align vertical */
	}
</style>
