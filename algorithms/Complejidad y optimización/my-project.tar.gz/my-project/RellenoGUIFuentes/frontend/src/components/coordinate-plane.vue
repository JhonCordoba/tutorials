<template>
	<div class="coordinate-plane">
		<div class="canvas-container">
			<canvas>
				<p>Your browser doesn't support canvas. Boo hoo!</p>
			</canvas>
		</div>
	</div>
</template>

<script lang="ts">
	import { defineComponent, onMounted, Ref, ref, watch } from "vue";
	import { CoordinatePlanePoint } from "../types";

	export default defineComponent({
		name: "CoordinatePlane",
		props: {
			data: {
				type: Array,
				default: () => {
					return [];
				},
			},
			/**
			 * realHeight is used for calculate the proportional graphic height in the coordinate plane
			 */
			realWidth: {
				type: Number,
				default: null,
				required: true,
			},
			/**
			 * realWidth is used for calculate the proportional graphic width in the coordinate plane
			 */
			realHeight: {
				type: Number,
				default: null,
				required: true,
			},
			/**
			 * realWidth is used for calculate the proportional graphic width in the coordinate plane
			 */
			isAnimate: {
				type: Boolean,
				default: true,
				required: false,
			},
		},
		setup(props) {
			const canvasWidth: Ref<number> = ref(0);
			const canvasHeight: Ref<number> = ref(0);

			let canvas: HTMLCanvasElement | null = null;
			let canvasContext: CanvasRenderingContext2D | null = null;
			let pointsState: CoordinatePlanePoint[] = [];
			let pointsFinalState: CoordinatePlanePoint[] = [];
			let animationFrameId = 0;
			let pointToDrawIndex = 0;

			onMounted(async () => {
				canvas = document.querySelector("canvas");
				if (!canvas) return;
				canvasWidth.value = canvas.width = Math.floor(window.innerWidth / 3);
				canvasHeight.value = canvas.height = canvasWidth.value; //this have to be a square.
				canvasContext = canvas.getContext("2d");
				if (!canvasContext) return;
				canvasContext.beginPath();
				canvasContext.moveTo(0, 0);
				canvasContext.lineTo(0, canvasHeight.value);
				canvasContext.lineTo(canvasWidth.value, canvasHeight.value);
				canvasContext.stroke();
				canvasContext.closePath();
				canvasContext.save();
			});

			/**
			 * take the real total height and the real total width, and the coordinates of a point
			 * and return the coordinates in terms of proportion, so you can draw this point
			 * in any square
			 */
			function calculateProportion(
				realHeight: number,
				realWidth: number,
				realX: number,
				realY: number
			): [number, number] {
				const proportionWidth: number = (100 * realX) / realWidth / 100;
				const proportionHeight: number = (100 * realY) / realHeight / 100;

				return [proportionWidth, proportionHeight];
			}

			function clearCoordinatePlane() {
				canvasContext?.save();
				if (!canvasContext) return;
				canvasContext.fillStyle = "rgb(255, 255, 255)";
				canvasContext.fillRect(1, 0, canvasWidth.value, canvasHeight.value - 1);
				canvasContext.restore();
			}

			function drawPoints(points: CoordinatePlanePoint[]) {
				if (!canvasContext) return;
				canvasContext.save();

				clearCoordinatePlane();

				canvasContext.fillText(
					"X (" + props.realWidth + ")",
					canvasWidth.value - 35,
					canvasHeight.value - 4
				);
				canvasContext.fillText("Y (" + props.realHeight + ")", 3, 10);

				//we need to translate the origin point (0,0) to th lower left corner:
				canvasContext.translate(0, canvasHeight.value);
				//we need to set the y-axis grow when you are going up (from down to up)
				canvasContext.scale(1, -1);

				points.forEach((point, index) => {
					if (!canvasContext) return;
					canvasContext.beginPath();
					canvasContext.arc(
						point.westCoordinate,
						point.southCoordinate,
						4,
						0,
						Math.PI * 2
					);

					if (point.color) canvasContext.fillStyle = point.color;
					canvasContext.fill();

					canvasContext.save();
					//we need to set the y-axis grow when you are going down (from up to dows)
					//else the letters appear upside down
					canvasContext.scale(1, -1);
					const realCoordinates: CoordinatePlanePoint[] =
						props.data as CoordinatePlanePoint[];
					canvasContext.fillText(
						"(" +
							realCoordinates[index].westCoordinate.toString() +
							"," +
							realCoordinates[index].southCoordinate.toString() +
							")",
						point.westCoordinate - 25,
						-(point.southCoordinate - 10)
					);
					canvasContext.restore();
				});

				canvasContext.restore();
			}

			function drawPointsWithAnimation() {
				let rate: number = 2000;
				if (!props.isAnimate) rate = 0;

				let intervalId = setInterval(() => {
					if (pointToDrawIndex < pointsFinalState.length) {
						pointsState.push(pointsFinalState[pointToDrawIndex]);
						drawPoints(pointsState);
						pointToDrawIndex++;
					}

					animationFrameId = window.requestAnimationFrame(drawPointsWithAnimation);
					if (pointToDrawIndex >= pointsFinalState.length) {
						console.log("End of requestAnimationFrame");
						window.cancelAnimationFrame(animationFrameId);
						clearInterval(intervalId);
					}
				}, rate);
			}

			watch(
				() => props.data as CoordinatePlanePoint[],
				(newPoints: CoordinatePlanePoint[]) => {
					let pointsToDraw: CoordinatePlanePoint[] = [];

					newPoints.forEach((point) => {
						const equivalentCoordinatesProportion: [number, number] =
							calculateProportion(
								props.realHeight,
								props.realWidth,
								point.westCoordinate,
								point.southCoordinate
							);
						pointsToDraw.push({
							westCoordinate: equivalentCoordinatesProportion[0] * canvasWidth.value,
							southCoordinate:
								equivalentCoordinatesProportion[1] * canvasHeight.value,
							color: point.color,
						});
					});
					pointsFinalState = pointsToDraw;
					pointsState = [];
					pointToDrawIndex = 0;
					drawPointsWithAnimation();
				}
			);

			return {};
		},
	});
</script>

<style scoped>
	.canvas-container {
		border: solid 1px #46b2c5;
		display: inline-block;
		padding: 1em;
	}
	#canvas-tag-height {
		display: inline-block;
		top: 0;
	}

	#canvas-tag-width {
		display: inline-block;
	}
</style>
