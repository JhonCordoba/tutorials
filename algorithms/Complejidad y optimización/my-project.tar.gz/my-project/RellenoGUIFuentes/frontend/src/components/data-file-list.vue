<template>
	<h2>List of Model Instances:</h2>

	<div class="fileListContainer">
		<div
			v-for="dataFile in dataFiles"
			:key="dataFile"
			class="fileListElement"
			@click="calculateLandFillPosition(dataFile)"
		>
			{{ dataFile }}
		</div>
	</div>
</template>

<script lang="ts">
	import { defineComponent, Ref, ref, onMounted } from "vue";

	import {
		getDataFiles,
		calculateLandFillPositionRequest,
		getDataFile,
	} from "../requests/datafiles";
	import { CoordinatePlanePoint } from "../types";

	export default defineComponent({
		name: "DataFilesList",
		emits: ["updateGraphic"],
		setup(props, context) {
			const dataFiles: Ref<string[]> = ref([]);

			onMounted(async () => {
				const response = await getDataFiles();
				dataFiles.value = response;
			});

			async function calculateLandFillPosition(dataFileId: string) {
				const stringResult: string = (await calculateLandFillPositionRequest(dataFileId))
					.result;
				const arrayResult: string[] = stringResult.split(" ");

				//get the cities points:
				const dataFileDatail: string[] = (await getDataFile(dataFileId)).dataFile.split(
					"\n"
				);
				const realSizeSquare = Number.parseFloat(dataFileDatail[1].split("=")[1]);

				let locationsAux1 = dataFileDatail[3].split("=")[1];
				locationsAux1 = locationsAux1.split(",")[0].split("|")[1];
				let locationsAux2 = dataFileDatail[3].split("=")[1].split("|")[1].split(",")[1];

				const points: CoordinatePlanePoint[] = [];

				//add point that represents the first city
				points.push({
					westCoordinate: Number.parseFloat(locationsAux1),
					southCoordinate: Number.parseFloat(locationsAux2),
				});

				//add the points that represents the rest of cities
				for (let i = 4; i < dataFileDatail.length - 2; i++) {
					locationsAux1 = dataFileDatail[i].split(",")[0].split("|")[1];
					locationsAux2 = dataFileDatail[i].split(",")[1];
					points.push({
						westCoordinate: Number.parseFloat(locationsAux1),
						southCoordinate: Number.parseFloat(locationsAux2),
					});
				}

				//add point that represents the result
				points.push({
					westCoordinate: Number.parseFloat(arrayResult[2]),
					southCoordinate: Number.parseFloat(arrayResult[5]),
					color: "rgb(255, 0, 0)",
				});

				context.emit("updateGraphic", [points, realSizeSquare]);
			}

			return {
				dataFiles,
				calculateLandFillPosition,
			};
		},
	});
</script>

<style scoped>
	.fileListElement {
		border-bottom: 1px solid;
		margin-bottom: 2px;
		cursor: pointer;
	}

	.fileListElement:hover {
		font-size: 1.1em;
		font-style: bold;
	}

	h2 {
		margin-top: 0;
		margin-bottom: 10px;
		text-decoration: underline;
		text-align: left;
		font-size: 1.3em;
	}

	.fileListContainer {
		height: 30%;
		overflow-y: scroll;
	}
</style>
