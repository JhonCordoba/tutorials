<template>
	<HeaderApp />

	<div class="home">
		<div class="dataFileSection">
			<div class="dataFileForm">
				<CreateDataFileForm @update-graphic="updateGraphic($event)" />
			</div>
			<div class="dataFileList">
				<DataFilesList @update-graphic="updateGraphic($event)" />
			</div>
		</div>

		<div class="coordinatePlane">
			<CoordinatePlane
				:data="dataGraphic"
				:real-height="realSizeSquare"
				:real-width="realSizeSquare"
				:is-animate="isAnimate"
			/>
		</div>
	</div>
</template>

<script lang="ts">
	import { defineComponent, onMounted, Ref, ref } from "vue";
	import CreateDataFileForm from "../components/create-data-file-form.vue";
	import DataFilesList from "../components/data-file-list.vue";
	import CoordinatePlane from "../components/coordinate-plane.vue";
	import HeaderApp from "../components/Header.vue";
	import { CoordinatePlanePoint } from "../types";

	//import Swal from "sweetalert2";

	export default defineComponent({
		name: "Home",
		components: {
			HeaderApp: HeaderApp,
			CreateDataFileForm: CreateDataFileForm,
			DataFilesList: DataFilesList,
			CoordinatePlane: CoordinatePlane,
		},
		setup() {
			const dataGraphic: Ref<CoordinatePlanePoint[]> = ref([]);
			const realSizeSquare: Ref<Number> = ref(3);
			const isAnimate: Ref<boolean | null> = ref(true);

			onMounted(() => {});

			function updateGraphic(data: [CoordinatePlanePoint[], number, boolean?]) {
				dataGraphic.value = data[0];
				realSizeSquare.value = data[1];
				//isAnimate default: true:
				isAnimate.value = data[2] === undefined || data[2] === true ? true : false;
			}

			return {
				dataGraphic,
				updateGraphic,
				realSizeSquare,
				isAnimate,
			};
		},
	});
</script>

<style scoped>
	.home {
		display: flex;
		justify-content: center;
		height: 100%;
	}
	.coordinatePlane {
		width: 50%;
	}
	.dataFileSection {
		display: flex;
		width: 50%;
		flex-wrap: wrap;
	}
	.dataFileForm {
		width: 100%;
		margin-left: 3px;
		box-shadow: 0px 5px 1px -3px rgba(84, 173, 214, 0.6);
	}
	.dataFileList {
		width: 100%;
		margin-bottom: 5px;
		height: 70%;
	}
</style>
